from pymongo import MongoClient

class AnimalShelterCRUD:
    def __init__(self,username, password, host, port, database, collection):
        USER = username
        PASS = password
        HOST = host
        PORT = port
        DB = database
        COL = collection     
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        """ Insert a document into MongoDB"""
        try:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        except Exception as e:
            print(f"Error inserting document: {e}")
            return False
        

# Create method to implement the R in CRUD.
    def read(self, query):
        try:
            cursor = self.collection.find(query)
            return list (cursor)
        except Exception as e:
            print(f"error querying documents: {e}")
            return []

# Create this method to implement the U in CRUD 
    def update(self, query, new_data):
        try:
            result = self.collection.update_many(query, {'$set' : new_data})
            return result.modified_count
        except Exception as e:
            print(f"an error occured: {e}")
            return 0
    
#create this method to implement the D in CRUD 
    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"an error occured: {e}")
            return 0
